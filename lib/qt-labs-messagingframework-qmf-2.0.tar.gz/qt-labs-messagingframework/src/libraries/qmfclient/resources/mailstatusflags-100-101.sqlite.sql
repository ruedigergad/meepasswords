UPDATE mailstatusflags SET name='CanTransmit' WHERE context='accountstatus' AND name='CanSend';
