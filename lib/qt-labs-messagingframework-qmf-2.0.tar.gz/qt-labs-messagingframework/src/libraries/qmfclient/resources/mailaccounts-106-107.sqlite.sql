ALTER TABLE mailaccounts ADD COLUMN lastsynchronized TIMESTAMP;
