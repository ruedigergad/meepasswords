ALTER TABLE mailfolders ADD COLUMN servercount INTEGER DEFAULT 0;
ALTER TABLE mailfolders ADD COLUMN serverunreadcount INTEGER DEFAULT 0;
