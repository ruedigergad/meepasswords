<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AddressSelectorWidget</name>
    <message>
        <location filename="addressselectorwidget.cpp" line="558"/>
        <source>No valid contacts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DetailsLineEdit</name>
    <message>
        <location filename="detailspage.cpp" line="113"/>
        <location filename="detailspage.cpp" line="115"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DetailsPage</name>
    <message>
        <location filename="detailspage.cpp" line="37"/>
        <source>(no subject)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="334"/>
        <source>Edit message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="344"/>
        <source>From contacts</source>
        <comment>Find recipient&apos;s phone number or email address from Contacts application</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="348"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="350"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="361"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="377"/>
        <source>CC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="393"/>
        <source>BCC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="409"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="420"/>
        <source>Delivery report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="424"/>
        <source>Read reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="430"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="443"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="712"/>
        <source>vCard describing %1</source>
        <comment>%1 = Person&apos;s name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="721"/>
        <source>vCard describing a contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="724"/>
        <source>vCard describing multiple contacts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EmailComposerPlugin</name>
    <message>
        <location filename="qmailcomposer.cpp" line="106"/>
        <location filename="qmailcomposer.cpp" line="108"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GenericComposerPlugin</name>
    <message>
        <location filename="qmailcomposer.cpp" line="179"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MMSComposerPlugin</name>
    <message>
        <location filename="qmailcomposer.cpp" line="217"/>
        <source>Multimedia message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qmailcomposer.cpp" line="219"/>
        <source>MMS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtopiaHomeMailMessageDelegate</name>
    <message>
        <location filename="qmailmessagedelegate.cpp" line="594"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RecipientEdit</name>
    <message>
        <location filename="detailspage.cpp" line="171"/>
        <source>Select Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="215"/>
        <location filename="detailspage.cpp" line="221"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="detailspage.cpp" line="218"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RecipientSelectorButton</name>
    <message>
        <location filename="detailspage.cpp" line="243"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideomailComposerPlugin</name>
    <message>
        <location filename="qmailcomposer.cpp" line="135"/>
        <source>Videomail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qmailcomposer.cpp" line="137"/>
        <source>Video mail</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
