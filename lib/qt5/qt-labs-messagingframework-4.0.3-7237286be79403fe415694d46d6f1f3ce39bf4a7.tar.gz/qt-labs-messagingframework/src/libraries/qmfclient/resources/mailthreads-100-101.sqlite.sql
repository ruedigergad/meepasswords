ALTER TABLE mailthreads ADD COLUMN parentaccountid INTEGER;
