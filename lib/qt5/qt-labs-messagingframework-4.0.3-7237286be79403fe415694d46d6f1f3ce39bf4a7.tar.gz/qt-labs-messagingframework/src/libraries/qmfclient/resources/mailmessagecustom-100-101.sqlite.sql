UPDATE mailmessagecustom
SET name = "qmf-content-size"
WHERE name = "qtopiamail-content-size"
