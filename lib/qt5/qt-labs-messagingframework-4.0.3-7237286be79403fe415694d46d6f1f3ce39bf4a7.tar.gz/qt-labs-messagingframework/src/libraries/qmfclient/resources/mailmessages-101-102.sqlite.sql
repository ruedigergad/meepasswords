ALTER TABLE mailmessages ADD COLUMN responseid INTEGER;
ALTER TABLE mailmessages ADD COLUMN responsetype INTEGER;
