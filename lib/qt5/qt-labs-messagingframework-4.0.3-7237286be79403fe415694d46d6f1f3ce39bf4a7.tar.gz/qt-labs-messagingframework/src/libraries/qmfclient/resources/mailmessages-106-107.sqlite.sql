UPDATE mailmessages SET previousparentfolderid = NULL;
