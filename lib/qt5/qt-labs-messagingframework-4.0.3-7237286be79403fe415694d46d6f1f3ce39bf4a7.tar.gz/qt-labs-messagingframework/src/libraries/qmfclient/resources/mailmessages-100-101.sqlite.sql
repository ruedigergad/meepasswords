UPDATE mailmessages SET mailfile = 'qtopiamailfile:' || mailfile WHERE mailfile <> '';

