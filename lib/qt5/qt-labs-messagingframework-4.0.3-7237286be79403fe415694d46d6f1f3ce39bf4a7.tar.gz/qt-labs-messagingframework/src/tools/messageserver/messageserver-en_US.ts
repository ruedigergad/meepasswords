<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>SmtpClient</name>
    <message numerus="yes">
        <location filename="smtpclient.cpp" line="516"/>
        <source>Sent %n messages</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
</context>
</TS>
