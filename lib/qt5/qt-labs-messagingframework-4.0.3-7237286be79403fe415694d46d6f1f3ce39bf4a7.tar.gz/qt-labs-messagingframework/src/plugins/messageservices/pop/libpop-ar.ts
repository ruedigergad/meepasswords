<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>PopClient</name>
    <message>
        <location filename="popclient.cpp" line="230"/>
        <source>Logging in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popclient.cpp" line="343"/>
        <source>Previewing</source>
        <comment>Previewing &lt;no of messages&gt;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popclient.cpp" line="345"/>
        <source>Completing %1 / %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popclient.cpp" line="452"/>
        <source>Removing old messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popclient.cpp" line="488"/>
        <source>Logging out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popclient.cpp" line="673"/>
        <source>Cancelled by user</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PopSettings</name>
    <message>
        <location filename="popsettings.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="56"/>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="82"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="111"/>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="137"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="163"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="180"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="185"/>
        <source>SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="190"/>
        <source>TLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="204"/>
        <source>Delete mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="226"/>
        <source>Skip larger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="248"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="270"/>
        <source>Disable when Roaming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="286"/>
        <source>min</source>
        <comment>short for minutes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="popsettings.ui" line="314"/>
        <source>K</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMailMessageService</name>
    <message>
        <location filename="popservice.cpp" line="196"/>
        <source>POP</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
