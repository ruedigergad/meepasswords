<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>SmtpClient</name>
    <message numerus="yes">
        <location filename="smtpclient.cpp" line="429"/>
        <source>Sent %n messages</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
</context>
</TS>
