<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name></name>
    <message>
        <location filename="smtpsettings.cpp" line="47"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMailMessageService</name>
    <message>
        <location filename="smtpservice.cpp" line="160"/>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SmtpClient</name>
    <message>
        <location filename="smtpclient.cpp" line="51"/>
        <source>Cannot send message; transport in use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpclient.cpp" line="57"/>
        <source>Cannot send message without account configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpclient.cpp" line="64"/>
        <source>Cannot send message without SMTP server configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpclient.cpp" line="157"/>
        <source>Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpclient.cpp" line="384"/>
        <source>Sending: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="smtpclient.cpp" line="429"/>
        <source>Sent %n messages</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="smtpclient.cpp" line="446"/>
        <source>Cancelled by user</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SmtpSettings</name>
    <message>
        <location filename="smtpsettings.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="56"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="82"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="108"/>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="134"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="160"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="177"/>
        <location filename="smtpsettings.ui" line="218"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="182"/>
        <source>SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="187"/>
        <source>TLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="201"/>
        <source>Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="223"/>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="228"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="242"/>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="271"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="303"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="319"/>
        <source>Set...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtpsettings.ui" line="332"/>
        <source>Default sending account</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
